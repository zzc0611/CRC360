package com.appinterface.bean;

import java.io.Serializable;
import java.sql.Date;

public class MemberInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String memb_id;
	private String memb_name;
	private String company_name;
	private int gender;
	private String memb_birth;
	private String memb_doc_no;  // ֤������
	private String memb_phone_mobile;
	private String memb_email;
	
	private String memb_sponsor_name; // �Ƽ���
	private String memb_upline_name;  // ������
	private String memb_joindate;
	private String KIV;
	private String shop_id;
	private String memb_photo_status;
	
	
	public String getMemb_photo_status() {
		return memb_photo_status;
	}
	public void setMemb_photo_status(String memb_photo_status) {
		this.memb_photo_status = memb_photo_status;
	}
	public String getShop_id() {
		return shop_id;
	}
	public void setShop_id(String shop_id) {
		this.shop_id = shop_id;
	}
	public String getMemb_id() {
		return memb_id;
	}
	public void setMemb_id(String memb_id) {
		this.memb_id = memb_id;
	}
	public String getMemb_name() {
		return memb_name;
	}
	public void setMemb_name(String memb_name) {
		this.memb_name = memb_name;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	
	public int getGender() {
		return gender;
	}
	public void setGender(int gender) {
		this.gender = gender;
	}
	public String getMemb_birth() {
		return memb_birth;
	}
	public void setMemb_birth(String memb_birth) {
		this.memb_birth = memb_birth;
	}
	public String getMemb_doc_no() {
		return memb_doc_no;
	}
	public void setMemb_doc_no(String memb_doc_no) {
		this.memb_doc_no = memb_doc_no;
	}
	public String getMemb_phone_mobile() {
		return memb_phone_mobile;
	}
	public void setMemb_phone_mobile(String memb_phone_mobile) {
		this.memb_phone_mobile = memb_phone_mobile;
	}
	public String getMemb_email() {
		return memb_email;
	}
	public void setMemb_email(String memb_email) {
		this.memb_email = memb_email;
	}


	public String getMemb_sponsor_name() {
		return memb_sponsor_name;
	}
	public void setMemb_sponsor_name(String memb_sponsor_name) {
		this.memb_sponsor_name = memb_sponsor_name;
	}
	public String getMemb_upline_name() {
		return memb_upline_name;
	}
	public void setMemb_upline_name(String memb_upline_name) {
		this.memb_upline_name = memb_upline_name;
	}
	public String getMemb_joindate() {
		return memb_joindate;
	}
	public void setMemb_joindate(String memb_joindate) {
		this.memb_joindate = memb_joindate;
	}
	public String getKIV() {
		return KIV;
	}
	public void setKIV(String kIV) {
		KIV = kIV;
	}
	@Override
	public String toString() {
		return "MemberInfo [memb_id=" + memb_id + ", memb_name=" + memb_name
				+ ", company_name=" + company_name + ", gender=" + gender
				+ ", memb_birth=" + memb_birth + ", memb_doc_no=" + memb_doc_no
				+ ", memb_phone_mobile=" + memb_phone_mobile + ", memb_email="
				+ memb_email + ", memb_sponsor_name=" + memb_sponsor_name
				+ ", memb_upline_name=" + memb_upline_name + ", memb_joindate="
				+ memb_joindate + ", KIV=" + KIV + "]";
	}
	
	
	
}
