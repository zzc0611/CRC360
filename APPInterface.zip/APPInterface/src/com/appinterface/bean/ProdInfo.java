package com.appinterface.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class ProdInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String pid;
	private String pname;
	private String psize;
	private BigDecimal pprice;
	private int pnum;
	private BigDecimal ptotal;
	private BigDecimal ppv;
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPsize() {
		return psize;
	}
	public void setPsize(String psize) {
		this.psize = psize;
	}
	public BigDecimal getPprice() {
		return pprice;
	}
	public void setPprice(BigDecimal pprice) {
		this.pprice = pprice;
	}
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public BigDecimal getPtotal() {
		return ptotal;
	}
	public void setPtotal(BigDecimal ptotal) {
		this.ptotal = ptotal;
	}
	public BigDecimal getPpv() {
		return ppv;
	}
	public void setPpv(BigDecimal ppv) {
		this.ppv = ppv;
	}
	
	

}
