package com.appinterface.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class BonusInfo implements Serializable{

	private static final long serialVersionUID = 1L;
	private String dt_bns_bns_code; //�¶ȱ�ʶ
	private String dt_bns_memb_code; //��Ա����
	private int dt_bns_rank_type;// ��Ա�¶�����
	private BigDecimal dt_bns_sale_amt;//�¶����۶�
	private BigDecimal dt_bns_pv;//�¶�pv
	private BigDecimal dt_bns_apv; //�ۼ�pv
	private BigDecimal dt_bns_opb_amt; //opb����
	private BigDecimal dt_bns_ldb_amt; //ldb����
	private BigDecimal dt_bns_lsb_amt; //lsb����
	private BigDecimal dt_bns_pgb_point; //pgb�������
	private BigDecimal dt_bns_pgb_amt; //pgb����
	private BigDecimal dt_bns_lgb_amt; //lgb����
	private BigDecimal dt_bns_ltf_point; //ltf�������
	private BigDecimal dt_bns_ltf_amt; //ltf������
	private BigDecimal dt_bns_lcf_point; //lcf�������
	private BigDecimal dt_bns_lcf_amt; //lcf������
	private BigDecimal dt_bns_lvf_point; //lvf�������
	private BigDecimal dt_bns_lvf_amt; //lvf������
	private BigDecimal dt_bns_reserve_amt; //�¶Ȼ����ܶ��
	private BigDecimal dt_bns_amt; //�¶Ƚ����ܶ��
	
	public String getDt_bns_bns_code() {
		return dt_bns_bns_code;
	}
	public void setDt_bns_bns_code(String dt_bns_bns_code) {
		this.dt_bns_bns_code = dt_bns_bns_code;
	}
	public String getDt_bns_memb_code() {
		return dt_bns_memb_code;
	}
	public void setDt_bns_memb_code(String dt_bns_memb_code) {
		this.dt_bns_memb_code = dt_bns_memb_code;
	}
	public int getDt_bns_rank_type() {
		return dt_bns_rank_type;
	}
	public void setDt_bns_rank_type(int dt_bns_rank_type) {
		this.dt_bns_rank_type = dt_bns_rank_type;
	}
	public BigDecimal getDt_bns_sale_amt() {
		return dt_bns_sale_amt;
	}
	public void setDt_bns_sale_amt(BigDecimal dt_bns_sale_amt) {
		this.dt_bns_sale_amt = dt_bns_sale_amt;
	}
	public BigDecimal getDt_bns_pv() {
		return dt_bns_pv;
	}
	public void setDt_bns_pv(BigDecimal dt_bns_pv) {
		this.dt_bns_pv = dt_bns_pv;
	}
	public BigDecimal getDt_bns_apv() {
		return dt_bns_apv;
	}
	public void setDt_bns_apv(BigDecimal dt_bns_apv) {
		this.dt_bns_apv = dt_bns_apv;
	}
	public BigDecimal getDt_bns_opb_amt() {
		return dt_bns_opb_amt;
	}
	public void setDt_bns_opb_amt(BigDecimal dt_bns_opb_amt) {
		this.dt_bns_opb_amt = dt_bns_opb_amt;
	}
	public BigDecimal getDt_bns_ldb_amt() {
		return dt_bns_ldb_amt;
	}
	public void setDt_bns_ldb_amt(BigDecimal dt_bns_ldb_amt) {
		this.dt_bns_ldb_amt = dt_bns_ldb_amt;
	}
	public BigDecimal getDt_bns_lsb_amt() {
		return dt_bns_lsb_amt;
	}
	public void setDt_bns_lsb_amt(BigDecimal dt_bns_lsb_amt) {
		this.dt_bns_lsb_amt = dt_bns_lsb_amt;
	}
	public BigDecimal getDt_bns_pgb_point() {
		return dt_bns_pgb_point;
	}
	public void setDt_bns_pgb_point(BigDecimal dt_bns_pgb_point) {
		this.dt_bns_pgb_point = dt_bns_pgb_point;
	}
	public BigDecimal getDt_bns_pgb_amt() {
		return dt_bns_pgb_amt;
	}
	public void setDt_bns_pgb_amt(BigDecimal dt_bns_pgb_amt) {
		this.dt_bns_pgb_amt = dt_bns_pgb_amt;
	}
	public BigDecimal getDt_bns_lgb_amt() {
		return dt_bns_lgb_amt;
	}
	public void setDt_bns_lgb_amt(BigDecimal dt_bns_lgb_amt) {
		this.dt_bns_lgb_amt = dt_bns_lgb_amt;
	}
	public BigDecimal getDt_bns_ltf_point() {
		return dt_bns_ltf_point;
	}
	public void setDt_bns_ltf_point(BigDecimal dt_bns_ltf_point) {
		this.dt_bns_ltf_point = dt_bns_ltf_point;
	}
	public BigDecimal getDt_bns_ltf_amt() {
		return dt_bns_ltf_amt;
	}
	public void setDt_bns_ltf_amt(BigDecimal dt_bns_ltf_amt) {
		this.dt_bns_ltf_amt = dt_bns_ltf_amt;
	}
	public BigDecimal getDt_bns_lcf_point() {
		return dt_bns_lcf_point;
	}
	public void setDt_bns_lcf_point(BigDecimal dt_bns_lcf_point) {
		this.dt_bns_lcf_point = dt_bns_lcf_point;
	}
	public BigDecimal getDt_bns_lcf_amt() {
		return dt_bns_lcf_amt;
	}
	public void setDt_bns_lcf_amt(BigDecimal dt_bns_lcf_amt) {
		this.dt_bns_lcf_amt = dt_bns_lcf_amt;
	}
	public BigDecimal getDt_bns_lvf_point() {
		return dt_bns_lvf_point;
	}
	public void setDt_bns_lvf_point(BigDecimal dt_bns_lvf_point) {
		this.dt_bns_lvf_point = dt_bns_lvf_point;
	}
	public BigDecimal getDt_bns_lvf_amt() {
		return dt_bns_lvf_amt;
	}
	public void setDt_bns_lvf_amt(BigDecimal dt_bns_lvf_amt) {
		this.dt_bns_lvf_amt = dt_bns_lvf_amt;
	}
	public BigDecimal getDt_bns_reserve_amt() {
		return dt_bns_reserve_amt;
	}
	public void setDt_bns_reserve_amt(BigDecimal dt_bns_reserve_amt) {
		this.dt_bns_reserve_amt = dt_bns_reserve_amt;
	}
	public BigDecimal getDt_bns_amt() {
		return dt_bns_amt;
	}
	public void setDt_bns_amt(BigDecimal dt_bns_amt) {
		this.dt_bns_amt = dt_bns_amt;
	}
	@Override
	public String toString() {
		return "BonusInfo [dt_bns_bns_code=" + dt_bns_bns_code
				+ ", dt_bns_memb_code=" + dt_bns_memb_code
				+ ", dt_bns_rank_type=" + dt_bns_rank_type
				+ ", dt_bns_sale_amt=" + dt_bns_sale_amt + ", dt_bns_pv="
				+ dt_bns_pv + ", dt_bns_apv=" + dt_bns_apv
				+ ", dt_bns_opb_amt=" + dt_bns_opb_amt + ", dt_bns_ldb_amt="
				+ dt_bns_ldb_amt + ", dt_bns_lsb_amt=" + dt_bns_lsb_amt
				+ ", dt_bns_pgb_point=" + dt_bns_pgb_point
				+ ", dt_bns_pgb_amt=" + dt_bns_pgb_amt + ", dt_bns_lgb_amt="
				+ dt_bns_lgb_amt + ", dt_bns_ltf_point=" + dt_bns_ltf_point
				+ ", dt_bns_ltf_amt=" + dt_bns_ltf_amt + ", dt_bns_lcf_point="
				+ dt_bns_lcf_point + ", dt_bns_lcf_amt=" + dt_bns_lcf_amt
				+ ", dt_bns_lvf_point=" + dt_bns_lvf_point
				+ ", dt_bns_lvf_amt=" + dt_bns_lvf_amt
				+ ", dt_bns_reserve_amt=" + dt_bns_reserve_amt
				+ ", dt_bns_amt=" + dt_bns_amt + "]";
	}
	

}
