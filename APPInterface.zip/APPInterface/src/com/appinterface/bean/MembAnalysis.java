package com.appinterface.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class MembAnalysis implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String bns_code;
	private String distributorid;
	private String rank;
	private BigDecimal pv;
	private BigDecimal apv;
	private BigDecimal bnsTotal;
	private int levelnum;
	private String name;
	private BigDecimal gpv;
	private String active;
	
	
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigDecimal getGpv() {
		return gpv;
	}
	public void setGpv(BigDecimal gpv) {
		this.gpv = gpv;
	}
	public String getBns_code() {
		return bns_code;
	}
	public void setBns_code(String bns_code) {
		this.bns_code = bns_code;
	}
	
	public String getDistributorid() {
		return distributorid;
	}
	public void setDistributorid(String distributorid) {
		this.distributorid = distributorid;
	}
	public String getRank() {
		return rank;
	}
	public void setRank(String rank) {
		this.rank = rank;
	}
	public BigDecimal getPv() {
		return pv;
	}
	public void setPv(BigDecimal pv) {
		this.pv = pv;
	}
	public BigDecimal getApv() {
		return apv;
	}
	public void setApv(BigDecimal apv) {
		this.apv = apv;
	}
	public BigDecimal getBnsTotal() {
		return bnsTotal;
	}
	public void setBnsTotal(BigDecimal bnsTotal) {
		this.bnsTotal = bnsTotal;
	}
	public int getLevelnum() {
		return levelnum;
	}
	public void setLevelnum(int levelnum) {
		this.levelnum = levelnum;
	}
	
	

}
