package com.appinterface.common;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import java.io.ByteArrayOutputStream;
import java.security.Key;
import java.security.Security;

import javax.crypto.SecretKeyFactory;  
import javax.crypto.spec.DESedeKeySpec;  
import javax.crypto.spec.IvParameterSpec; 

import com.sun.org.apache.xml.internal.security.utils.Base64;




	
	  
public class ThreeDes {  
	  
	 // ��Կ  
    private final static String secretKey = "bf1suma4mktarard5frica54&szhk@app";  
    // ����  
    private final static String iv = "01234567";  
    // �ӽ���ͳһʹ�õı��뷽ʽ  
    private final static String encoding = "utf-8";  
  
    /** 
     * 3DES���� 
     *  
     * @param plainText ��ͨ�ı� 
     * @return 
     * @throws Exception  
     */  
    public static String encode(String plainText) throws Exception {  
        Key deskey = null;  
        DESedeKeySpec spec = new DESedeKeySpec(secretKey.getBytes());  
        SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("desede");  
        deskey = keyfactory.generateSecret(spec);  
  
        Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");  
        IvParameterSpec ips = new IvParameterSpec(iv.getBytes());  
        cipher.init(Cipher.ENCRYPT_MODE, deskey, ips);  
        byte[] encryptData = cipher.doFinal(plainText.getBytes(encoding));  
        return Base64.encode(encryptData);  
    }  
  
    /** 
     * 3DES���� 
     *  
     * @param encryptText �����ı� 
     * @return 
     * @throws Exception 
     */  
    public static String decode(String encryptText) throws Exception { 
    	
        Key deskey = null;  
        DESedeKeySpec spec = new DESedeKeySpec(secretKey.getBytes());  
        SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("desede");  
        deskey = keyfactory.generateSecret(spec);  
        Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");  
        IvParameterSpec ips = new IvParameterSpec(iv.getBytes());  
        cipher.init(Cipher.DECRYPT_MODE, deskey, ips);  
  
        byte[] decryptData = cipher.doFinal(Base64.decode(encryptText));  
  
        return new String(decryptData, encoding);  
    }  
    
//    public static void main(String[] args) {
//    	ThreeDes t =new ThreeDes();
//    	
//    	String a = "BFSumalogin?distributorid=BJ030303&password=BJ030303&item=11111111&t=123456789";
//    	
//    	try {
//			String jiam =t.encode(a);
//			System.out.println("jiami---"+jiam);
//			
//			String jiemi =t.decode(jiam);
//			System.out.println(jiemi);
//			
//			
//			
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//    	
//	}
  
}  