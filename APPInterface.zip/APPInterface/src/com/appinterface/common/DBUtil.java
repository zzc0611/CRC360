package com.appinterface.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	
	public Connection getConn(){
		Connection con =null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection( 
					"jdbc:oracle:thin:@192.168.60.51:1521:orcl","BFAFRICA_4","ASd150116");
			return con;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	
//	public static void main(String[] args) {    
//		DBUtil basedao=new DBUtil();    
//		Connection conn= basedao.getConn();    
//        if(conn==null){    
//            System.out.println("��oracle���ݿ�����ʧ�ܣ�");    
//        }else{    
//            System.out.println("��oracle���ݿ����ӳɹ���");    
//        }    
//     }   
}
