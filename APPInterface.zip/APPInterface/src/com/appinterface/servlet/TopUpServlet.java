package com.appinterface.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appinterface.bean.MembAnalysis;
import com.appinterface.common.ThreeDes;
import com.appinterface.service.impl.GetDateImpl;
import com.appinterface.service.impl.ReportImpl;

/**
 * Servlet implementation class TopUpServlet
 */
@WebServlet("/TopUpServlet")
public class TopUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ThreeDes threeDes = new ThreeDes();   
	ReportImpl report = new ReportImpl();
	GetDateImpl getDate = new GetDateImpl();   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TopUpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		int result ;
		HashMap<String,Object> map = new HashMap<String , Object>();
		JSONObject json =JSONObject.fromObject("{}");
		
		
		String distributorid = request.getParameter("distributorid");
		String imei = request.getParameter("imei");
		String t =request.getParameter("t");
		String key =request.getParameter("key");
		
		String skey ="BFSuma"+"topUp?distributorid="+distributorid+"&imei="+imei+"&t="+t;
		String k;
		try {
			k = threeDes.decode(key);
			System.out.println(k);
			if(!skey.equals(k)){
				json.put("errorcode", 100); //key ֵ����
				json.put("result", -1);
				response.setCharacterEncoding("UTF-8"); 
				response.getWriter().print(json);  
			}else{
				int axit = getDate.imeiAxit(distributorid, imei);   //��ѯ�Ƿ����ֻ��ϵ�¼
				if(axit == -1){
					json.put("result", -1);
					json.put("errorcode", 112);/*imei ������ ����ȣ����˺�û�����ֻ��ϵ�¼��*/
					response.getWriter().print(json); 
				}else{
				
					String membcode = report.findMembCode(distributorid);  //����id��membcode
					//System.out.println("membcode----:"+membcode);
					if("".equals(membcode)){
						json.put("errorcode", 300); //�û�������
						json.put("result", -1);
						response.setCharacterEncoding("UTF-8"); 
						response.getWriter().print(json);
						return;
					}
					String bns_code = getDate.getBnscode(membcode);   // ��ѯ����������������·� ��������Ϣ��������
					if("".equals(bns_code)){
						json.put("errorcode", 321); //�û�û�м��������
						json.put("result", -1);
						response.setCharacterEncoding("UTF-8"); 
						response.getWriter().print(json);
						return;
					}
					json.put("bonuscode", bns_code);
					map = getDate.getTopup(membcode, bns_code);  // �õ������pv  cgv  ����top-up
					int rank = (int) map.get("rank");
					if(rank >7){
						json.put("errorcode", 777); //"rank over leader,can not get top-up"
						json.put("result", -1);
						response.getWriter().print(json); 
						return;
					}
					BigDecimal ppv = (BigDecimal) map.get("pv");
					BigDecimal cgv =(BigDecimal) map.get("cpv");
					if(rank>=1 && rank<=3 && ppv.compareTo(BigDecimal.valueOf(20)) == -1){
						json.put("message", "Top-up to 20PV to be active");
						json.put("result", 0);
						response.getWriter().print(json);
						return;
					}
					if(rank==4 && ppv.compareTo(BigDecimal.valueOf(30)) == -1){
						json.put("message", "Top-up to 30PV to be active");
						json.put("result", 0);
						response.getWriter().print(json);
						return;
					}
					if(rank==5 && ppv.compareTo(BigDecimal.valueOf(40)) == -1){
						json.put("message", "Top-up to 40PV to be active");
						json.put("result", 0);
						response.getWriter().print(json);
						return;
					}
					if(rank==6 && ppv.compareTo(BigDecimal.valueOf(50)) == -1){
						json.put("message", "Top-up to 50PV to be active");
						json.put("result", 0);
						response.getWriter().print(json);
						return;
					}
					if(rank==7 && ppv.compareTo(BigDecimal.valueOf(50)) == -1){
						json.put("message", "Top-up to 50PV to be active");
						json.put("result", 0);
						response.getWriter().print(json);
						return;
					}
					
					
					if(rank == 3 && ppv.compareTo(BigDecimal.valueOf(30))!=-1 && cgv.compareTo(BigDecimal.valueOf(900))!=-1 && cgv.compareTo(BigDecimal.valueOf(1000))==-1){
						json.put("message","Top-up another " + BigDecimal.valueOf(1000).subtract(cgv).doubleValue() + " GPV to be a 4 star");
						json.put("result", 0);
						response.getWriter().print(json);
						return;
					}
					
					if(rank == 4 && ppv.compareTo(BigDecimal.valueOf(40))!=-1 && cgv.compareTo(BigDecimal.valueOf(4500))!=-1 && cgv.compareTo(BigDecimal.valueOf(5000))==-1){
						json.put("message","Top-up another " + BigDecimal.valueOf(5000).subtract(cgv).doubleValue() + " GPV to be a 5 star");
						json.put("result", 0);
						response.getWriter().print(json); 
						return;
					}
					
					if(rank == 5 && ppv.compareTo(BigDecimal.valueOf(50))!=-1 && cgv.compareTo(BigDecimal.valueOf(7000))!=-1 && cgv.compareTo(BigDecimal.valueOf(8000))==-1){
						json.put("message","Top-up another " + BigDecimal.valueOf(8000).subtract(cgv).doubleValue() + " GPV to be a 6 star");
						json.put("result", 0);
						response.getWriter().print(json);
						return;
					}
					
					if(rank == 6 && ppv.compareTo(BigDecimal.valueOf(50))!=-1 && cgv.compareTo(BigDecimal.valueOf(10000))!=-1 && cgv.compareTo(BigDecimal.valueOf(12000))==-1){
						json.put("message","Top-up another " + BigDecimal.valueOf(12000).subtract(cgv).doubleValue() + " GPV to be a 7 star");
						json.put("result", 0);
						response.getWriter().print(json); 
						return;
					}
					
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
