package com.appinterface.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appinterface.bean.BonusInfo;
import com.appinterface.common.ThreeDes;
import com.appinterface.service.impl.GetDateImpl;

/**
 * Servlet implementation class SubmitOrderServlet
 */
@WebServlet("/SubmitOrderServlet")
public class SubmitOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ThreeDes threeDes = new ThreeDes();
	GetDateImpl getDate = new GetDateImpl();   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SubmitOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int result ;
		//List<BonusInfo> datelist= new ArrayList<BonusInfo>();
		JSONObject json =JSONObject.fromObject("{}");
		
		
		String distributorid = request.getParameter("distributorid");
		String imei = request.getParameter("imei");
		String pinfo =  request.getParameter("pinfo");
		System.out.println("submitOrder--"+distributorid +"```"+pinfo+"````"+imei);
		
		JSONArray parray = new JSONArray().fromObject(pinfo);
//		JSONObject q = (JSONObject) parray.get(0);
//		String i =  q.getString("pname");
		
		String t =request.getParameter("t");
		String key =request.getParameter("key");
		
		
		
		String skey ="BFSuma"+"submitOrder?distributorid="+distributorid+"&pinfo="+pinfo+"&imei="+imei+"&t="+t;
		
		String k;
		try {
			k = threeDes.decode(key);
			System.out.println(k);
			if(!skey.equals(k)){
				json.put("errorcode", 100); //key ֵ����
				json.put("result", -1);
				response.setCharacterEncoding("UTF-8"); 
				response.getWriter().print(json);  
			}else{
				int axit = getDate.imeiAxit(distributorid, imei);
				if(axit == -1){
					json.put("result", -1);
					json.put("errorcode", 112);/*imei ������ ����ȣ����˺�û�����ֻ��ϵ�¼��*/
					response.getWriter().print(json); 
				}else{
					String orderid =getDate.getOrderid(t);
					int i = getDate.insertDetail(parray,orderid);
					if(i == -1){
						json.put("errorcode", 117);/*���ݲ���ȷ*/
						json.put("result", -1);
						response.getWriter().print(json);
					}
					
					double total = getDate.getTotal(orderid);
					System.out.println("total--------"+total);
					
					result =getDate.insertOrder(orderid,distributorid,t,total);
				
					json.put("orderid", orderid);
					json.put("result", result);
					response.getWriter().print(json);  
					response.getWriter().flush();  
					response.getWriter().close(); 
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
