package com.appinterface.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.appinterface.common.ThreeDes;
import com.appinterface.service.impl.GetDateImpl;

import net.sf.json.JSONObject;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     

	
	ThreeDes threeDes = new ThreeDes();
	GetDateImpl getDate = new GetDateImpl(); 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int result ;
		JSONObject json =JSONObject.fromObject("{}");
		String imei = request.getParameter("imei");
		String distributorid = request.getParameter("distributorid");
		String password =request.getParameter("password");
		String invitecode = request.getParameter("invitecode");
		String t =request.getParameter("t");
		String key =request.getParameter("key");
		
		String skey ="BFSumaregister?distributorid="+distributorid+"&password="+password+"&invitecode="+invitecode+"&t="+t;
		
		//����
		String k;
		try {
			k = threeDes.decode(key);
			System.out.println(k);
			if(!skey.equals(k)){
				json.put("errorcode", 100); //key ֵ����
				json.put("result", -1);
				System.out.println(json.toString());
				response.setCharacterEncoding("UTF-8"); 
				response.getWriter().print(json);  
			}else{
				if(getDate.activeState(distributorid) == 0){
					json.put("errorcode" , 115); //�û��Ѽ���  ����Ҫע��
					json.put("result", -1);
					System.out.println(json.toString());
					response.setCharacterEncoding("UTF-8"); 
					response.getWriter().print(json);
					return;
				}
				
				int inviteStatus = getDate.inviteCode(distributorid, invitecode);
				if(inviteStatus == -1){
					json.put("errorcode", 110); //������ֵ����ȷ 
					json.put("result", -1);
					//System.out.println(json.toString());
					response.setCharacterEncoding("UTF-8"); 
					response.getWriter().print(json);
					return;
				}
				result = getDate.register(distributorid, password, invitecode);
				if(result == -1){
					json.put("errorcode", 300); // distributor ������ 
				}
				json.put("result", result);
				//System.out.println(json.toString());
				response.getWriter().print(json);  
				response.getWriter().flush();  
		        response.getWriter().close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	
	
}
