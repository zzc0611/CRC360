package com.appinterface.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import com.appinterface.common.ThreeDes;
import com.appinterface.service.impl.GetAPPStautImple;
/**
 * 张志城
 * @author owner
 *
 */
public class APPFeedBackServlet extends HttpServlet{
	ThreeDes threeDes = new ThreeDes();
	GetAPPStautImple getDate = new GetAPPStautImple(); 

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int result ;
//		List<BonusInfo> datelist= new ArrayList<BonusInfo>();
		JSONObject json =JSONObject.fromObject("{}");
//		JSONArray dataArray = new JSONArray();
		
		String distributorid = request.getParameter("distributorid");
		String imei = request.getParameter("imei");
		String t =request.getParameter("t");
		String key =request.getParameter("key");
		String feedback = request.getParameter("feeback");
		//System.out.println("bonusInfo--"+distributorid +"```"+date+"````"+imei);
		
		String skey ="BFSuma"+"feedbackinfo?distributorid="+distributorid+"&imei="+imei+"&t="+t;
		
		String k;
		try {
			k = threeDes.decode(key);
			System.out.println(k);
			if(!skey.equals(k)){
				json.put("errorcode", 100); //key ֵ����
				json.put("result", -1);
				response.setCharacterEncoding("UTF-8"); 
				response.getWriter().print(json);  
			}else{
				int axit = getDate.imeiAxit(distributorid, imei);
				if(axit == -1){
					json.put("result", -1);
					json.put("errorcode", 112);/*imei 不存在 或不相等（该账号没有在手机上登录）*/
					response.getWriter().print(json); 
					response.getWriter().flush();  
			        response.getWriter().close(); 
				}else{
//				datelist =  getDate.getBonusInfo(distributorid,date, imei);
					result = getDate.getFeedBackResult(distributorid,feedback,t,imei);
//				dataArray = JSONArray.fromObject(datelist);
				//System.out.println(dataArray.toString());
					if(result==0){
						json.put("result", 0);
						json.put("message", "Feedback success");
					}else{
						json.put("result", -1);
						json.put("message", "Feedback failure");
					}
				
			
				System.out.println("feddback----"+json.toString());
				
				response.getWriter().print(json);  
				response.getWriter().flush();  
		        response.getWriter().close(); 
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
}
