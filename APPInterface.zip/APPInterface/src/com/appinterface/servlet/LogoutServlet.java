package com.appinterface.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import com.appinterface.common.ThreeDes;
import com.appinterface.service.impl.GetDateImpl;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ThreeDes threeDes = new ThreeDes();
	GetDateImpl getDate = new GetDateImpl(); 
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogoutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int result ;
		JSONObject json =JSONObject.fromObject("{}");
		
		String distributorid = request.getParameter("distributorid");
		String imei = request.getParameter("imei");
		String t =request.getParameter("t");
		String key =request.getParameter("key");
		//System.out.println("logout--"+distributorid+"----"+imei+"----"+t);
		
		String skey ="BFSuma"+"logout?distributorid="+distributorid+"&imei="+imei+"&t="+t;
		
		String k;
		try {
			k = threeDes.decode(key);
			System.out.println(k);
			if(!skey.equals(k)){
				json.put("errorcode", 100); //key ֵ����
				json.put("result", -1);
				response.setCharacterEncoding("UTF-8"); 
				response.getWriter().print(json);  
			}else{
				if(getDate.imeiAxit(distributorid, imei) == -1){
					json.put("errorcode", 112);//�û�û�е�¼
					json.put("result", -1);
					response.getWriter().print(json);  
					response.getWriter().flush();  
			        response.getWriter().close(); 
			        return;
				}
				
				result =  getDate.logout(distributorid, imei);
				if(result == -1){
					json.put("errorcode", 200);//�û������������
					json.put("result", -1);
					response.getWriter().print(json);  
					response.getWriter().flush();  
			        response.getWriter().close();
			        return;
				}
				json.put("result", result);
				json.put("imei", imei);
				response.getWriter().print(json);  
				response.getWriter().flush();  
		        response.getWriter().close();  
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
