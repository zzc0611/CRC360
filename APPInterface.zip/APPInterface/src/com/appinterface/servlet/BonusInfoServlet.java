package com.appinterface.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appinterface.bean.BonusInfo;
import com.appinterface.common.ThreeDes;
import com.appinterface.service.impl.GetDateImpl;

import java.security.Security;
import java.util.ArrayList;
import java.util.List;


/**
 * Servlet implementation class BonusInfoServlet
 */
@WebServlet("/BonusInfoServlet")
public class BonusInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ThreeDes threeDes = new ThreeDes();
	GetDateImpl getDate = new GetDateImpl(); 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BonusInfoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int result ;
		List<BonusInfo> datelist= new ArrayList<BonusInfo>();
		JSONObject json =JSONObject.fromObject("{}");
		JSONArray dataArray = new JSONArray();
		
		String distributorid = request.getParameter("distributorid");
		String imei = request.getParameter("imei");
		String date = request.getParameter("date");
		String t =request.getParameter("t");
		String key =request.getParameter("key");
		//System.out.println("bonusInfo--"+distributorid +"```"+date+"````"+imei);
		
		String skey ="BFSuma"+"bonusinfo?distributorid="+distributorid+"&date="+date+"&imei="+imei+"&t="+t;
		
		String k;
		try {
			k = threeDes.decode(key);
			System.out.println(k);
			if(!skey.equals(k)){
				json.put("errorcode", 100); //key ֵ����
				json.put("result", -1);
				response.setCharacterEncoding("UTF-8"); 
				response.getWriter().print(json);  
			}else{
				int axit = getDate.imeiAxit(distributorid, imei);
				if(axit == -1){
					json.put("result", -1);
					json.put("errorcode", 112);/*imei ������ ����ȣ����˺�û�����ֻ��ϵ�¼��*/
					response.getWriter().print(json); 
					response.getWriter().flush();  
			        response.getWriter().close(); 
				}else{
				datelist =  getDate.getBonusInfo(distributorid,date, imei);
				
				dataArray = JSONArray.fromObject(datelist);
				//System.out.println(dataArray.toString());
				
				json.put("result", 0);
				json.put("data", dataArray);
				//System.out.println("bonusinfo----"+json.toString());
				
				response.getWriter().print(json);  
				response.getWriter().flush();  
		        response.getWriter().close(); 
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}

}
