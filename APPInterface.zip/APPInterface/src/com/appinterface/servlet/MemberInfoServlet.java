package com.appinterface.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appinterface.bean.BonusInfo;
import com.appinterface.bean.MemberInfo;
import com.appinterface.common.ThreeDes;
import com.appinterface.service.impl.GetDateImpl;

/**
 * Servlet implementation class MemberInfoServlet
 */
@WebServlet("/MemberInfoServlet")
public class MemberInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ThreeDes threeDes = new ThreeDes();
	GetDateImpl getDate = new GetDateImpl();    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemberInfoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int result ;
		List<MemberInfo> datelist= new ArrayList<MemberInfo>();
		JSONObject json =JSONObject.fromObject("{}");
		JSONArray dataArray = new JSONArray();
		
		String distributorid = request.getParameter("distributorid");
		String imei = request.getParameter("imei");
		
		String t =request.getParameter("t");
		String key =request.getParameter("key");
		
		
		String skey ="BFSuma"+"membInfo?distributorid="+distributorid+"&imei="+imei+"&t="+t;
		
		String k;
		try {
			k = threeDes.decode(key);
			System.out.println(k);
			if(!skey.equals(k)){
				json.put("errorcode", 100); //key ֵ����
				json.put("result", -1);
				response.setCharacterEncoding("UTF-8"); 
				response.getWriter().print(json);  
			}else{
				int axit = getDate.imeiAxit(distributorid, imei);
				if(axit == -1){
					json.put("result", -1);
					json.put("errorcode", 112);/*imei ������ ����ȣ����˺�û�����ֻ��ϵ�¼��*/
					response.getWriter().print(json); 
				}else{
				 datelist =  getDate.getMemberInfo(distributorid); 
				
				dataArray = JSONArray.fromObject(datelist);
				//System.out.println(dataArray.toString());
				
				json.put("result", 0);
				json.put("data", dataArray);
				//System.out.println("membInfo----"+json.toString());
				
				response.getWriter().print(json);  
				response.getWriter().flush();  
		        response.getWriter().close(); 
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
