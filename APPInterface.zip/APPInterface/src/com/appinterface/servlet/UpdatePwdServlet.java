package com.appinterface.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.appinterface.common.ThreeDes;
import com.appinterface.service.impl.GetDateImpl;

import net.sf.json.JSONObject;

/**
 * Servlet implementation class UpdatePwdServlet
 */
@WebServlet("/UpdatePwdServlet")
public class UpdatePwdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	ThreeDes threeDes = new ThreeDes();
	GetDateImpl getDate = new GetDateImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatePwdServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int result ;
		JSONObject json =JSONObject.fromObject("{}");
		String distributorid = request.getParameter("distributorid");
		String t =request.getParameter("t");
		String key =request.getParameter("key");
		String imei = request.getParameter("imei");
		String newpwd  = request.getParameter("newpwd");
		String skey ="BFSumaupdatePwd?distributorid="+distributorid+"&newpwd="+newpwd+"&imei="+imei+"&t="+t;
		

		//����
		String k;
		try {
			k = threeDes.decode(key);
			if(!skey.equals(k)){
				json.put("errorcode", 100); //key ֵ����
				json.put("result", -1);
				response.setCharacterEncoding("UTF-8"); 
				response.getWriter().print(json);  
			}else{
				result = getDate.updatePwd(distributorid, newpwd);
				if(result == -1){
					json.put("errorcode", 300); //�û�������
				}
				json.put("result", result);
				response.getWriter().print(json);  
				response.getWriter().flush();  
		        response.getWriter().close();  
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
