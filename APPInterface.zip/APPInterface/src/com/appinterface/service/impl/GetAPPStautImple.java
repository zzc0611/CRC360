package com.appinterface.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.appinterface.common.DBUtil;

/**
 * 张志城
 * 
 * @author owner
 *
 */
public class GetAPPStautImple {
	DBUtil dbutil = new DBUtil();
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Connection conn = null;

	/**
	 * 查询是否在手机上登录
	 * 
	 * @param distributorid
	 * @param imei
	 * @return
	 */
	public int imeiAxit(String distributorid, String imei) {
		String oracle = "SELECT MEMB_LOGIN_PHONEIMEI FROM MEMB_MS WHERE MEMB_ID ='"
				+ distributorid + "'";

		System.out.println(oracle);
		try {
			conn = dbutil.getConn();
			pstmt = conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if (!rs.getString(1).equals(imei)) {
					return -1;
				}

				return 0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null) {
					conn.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// System.out.println(oracle);
		return -1;
	}

	// /////////////////////////////////////////////////
	/**
	 * 意见反馈
	 * 
	 * @param distributorid
	 * @param content
	 * @param date
	 * @param imei
	 * @return
	 */
	public int getFeedBackResult(String distributorid, String content,
			String date, String imei) {
		// String oracle =
		// "insert into App_Comment_Feedback(distributorid,content,time) values('"+distributorid+"','"+content+"','"+date+"')";
		String oracle = "INSERT INTO APP_COMMENT_FEEDBACK(DISTRIBUTORID,CONTENT,TIME) VALUES('"
				+ distributorid + "','" + content + "','" + date + "')";
		try {
			conn = dbutil.getConn();
			pstmt = conn.prepareStatement(oracle);
			pstmt.executeUpdate();
			// System.out.println("updateMembName----"+oracle);
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null) {
					conn.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return -1;
	}

	/**
	 * 版本信息监听
	 * 
	 * @param distributorid
	 * @param version
	 * @param date
	 * @return
	 */
	public String[] getUpdateVersion(String distributorid, String version,
			String date) {
		// TODO Auto-generated method stub
		return null;
	}
/**
 * 异常信息反馈
 * @param distributorid
 * @param exceptioninfo
 * @param mobile_type
 * @param oversion
 * @return
 */
	public int getExceptionResult(String distributorid, String exceptioninfo,
			String mobile_type, String oversion) {
		String oracle = "INSERT INTO app_exception_feedback(DISTRIBUTOR_ID,CONTENT,TIME) VALUES('"
				+ distributorid + "','" + exceptioninfo + "','" + mobile_type + "','" + oversion + "')";
		try {
			conn = dbutil.getConn();
			pstmt = conn.prepareStatement(oracle);
			pstmt.executeUpdate();
			// System.out.println("updateMembName----"+oracle);
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null) {
					conn.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return -1;
		
	}

}
