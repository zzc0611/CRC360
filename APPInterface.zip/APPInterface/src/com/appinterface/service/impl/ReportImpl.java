package com.appinterface.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.appinterface.bean.AppOrderInfo;
import com.appinterface.bean.BonusInfo;

import com.appinterface.bean.MembAnalysis;
import com.appinterface.bean.ProdInfo;
import com.appinterface.bean.SalesPerformance;
import com.appinterface.common.DBUtil;

public class ReportImpl {
	DBUtil dbutil =new DBUtil();
	PreparedStatement pstmt =null;
	ResultSet rs=null;
	Connection conn = null;
	
	public  String  findMembCode(String distributorid){
		String name = "" ;
		String oracle = "select memb_code from memb_ms where memb_id ='"+distributorid+"'";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs =pstmt.executeQuery();
			System.out.println(oracle);
			if(rs.next()){
				name =rs.getString(1);
				return name;
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		
		return name;
	}
	
	public List<SalesPerformance> reportSalesPerformance(String membcode , String month){
		List<SalesPerformance> list =new ArrayList<SalesPerformance>();
		try {
			conn =dbutil.getConn();
			String oracle = "SELECT a.dt_bns_bns_code,memb_ms.memb_id,rank_lt.lt_rank_title,a.dt_bns_pv,a.dt_bns_apv,a.dt_bns_amt,1 AS levelnum,memb_ms.memb_name name,a.dt_bns_gpv gpv"
					+ " FROM bns_dt a,memb_ms,rank_lt WHERE rank_lt.lt_rank_type = a.dt_bns_rank_type AND rank_lt.lt_rank_language_type =1 AND memb_ms.memb_code = a.dt_bns_memb_code "
					+ " AND a.dt_bns_bns_code = 'BM"+month+"' AND a.dt_bns_memb_code ='"+membcode+"' AND a.dt_bns_amt > 0 "
					+ " UNION "
					+ " SELECT a.dt_bns_bns_code,memb_ms.memb_id,rank_lt.lt_rank_title,a.dt_bns_pv,a.dt_bns_apv,a.dt_bns_amt,2 AS levelnum ,memb_ms.memb_name name,a.dt_bns_gpv gpv"
					+ " FROM bns_dt a,memb_ms,rank_lt WHERE rank_lt.lt_rank_type = a.dt_bns_rank_type AND rank_lt.lt_rank_language_type =1 "
					+ " AND memb_ms.memb_code=a.dt_bns_memb_code AND dt_bns_bns_code ='BM"+month+"' AND dt_bns_upline_memb_code ='"+membcode+"' AND dt_bns_amt > 0 "
					+ " UNION "
					+ " SELECT a.dt_bns_bns_code,memb_ms.memb_id,rank_lt.lt_rank_title,a.dt_bns_pv,a.dt_bns_apv,a.dt_bns_amt,3 AS levelnum ,memb_ms.memb_name name,a.dt_bns_gpv gpv"
					+ " FROM bns_dt a,memb_ms,rank_lt WHERE rank_lt.lt_rank_type = a.dt_bns_rank_type AND rank_lt.lt_rank_language_type =1 "
					+ " AND memb_ms.memb_code=a.dt_bns_memb_code AND dt_bns_bns_code ='BM"+month+"' AND  dt_bns_upline_memb_code IN(SELECT dt_bns_memb_code FROM bns_dt WHERE dt_bns_upline_memb_code ='"+membcode+"')"
					+ " AND dt_bns_amt > 0 ";
			pstmt = conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			System.out.println("reportSalesPerformance-------"+oracle);
			while(rs.next()){
				SalesPerformance spf = new SalesPerformance();
				spf.setBns_code(rs.getString(1));
				spf.setDistributorid(rs.getString(2));
				spf.setRank(rs.getString(3));
				spf.setPv(rs.getBigDecimal(4));
				spf.setApv(rs.getBigDecimal(5));
				spf.setBnsTotal(rs.getBigDecimal(6));
				spf.setLevelnum(rs.getInt(7));
				spf.setName(rs.getString(8));
				spf.setGpv(rs.getBigDecimal(9));
				list.add(spf);
				//return list;	
			}
			return list;
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
				try {
					if(conn != null){
						conn.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(rs != null){
						rs.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return list;
	}
	

	public List<HashMap<String,Object>> reportMyDPR(String distributorid,String year){
		List<HashMap<String,Object>> list =new ArrayList<HashMap<String,Object>>();
		try {
			conn =dbutil.getConn();
			String oracle = "SELECT m.memb_name,s.scb_no,v.ld_unit_name,v.unit_id,s.scb_date,s.scb_total_amt,s.scb_total_pv_amt,s.scb_code,s.scb_status"
					+ " FROM memb_ms m ,scb_ms s,vw_unit_detail v "
					+ " WHERE m.memb_code = s.scb_memb_code AND v.unit_code =s.scb_stoc_unit_code "
					+ " AND s.scb_status <> 4 AND v.ld_unit_language_type=1 AND m.memb_id='"+distributorid+"'"
					+ " AND EXTRACT(YEAR FROM s.scb_date)=to_number('"+year+"')";
			pstmt = conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			System.out.println("reportMyDPR-------"+oracle);
			while(rs.next()){
				HashMap<String,Object> map = new HashMap<String, Object>();
				map.put("membname", rs.getString(1));
				map.put("dprno", rs.getString(2));
				map.put("shopname", rs.getString(3));
				map.put("shopno", rs.getString(4));
				map.put("dprdate", rs.getString(5));
				map.put("total", rs.getBigDecimal(6));
				map.put("pv", rs.getBigDecimal(7));
				map.put("status", rs.getInt(9));
				String scb_code = rs.getString(8);
				List<ProdInfo> prodList= new ArrayList<ProdInfo>();
				prodList = selectProdByScb(scb_code);
				map.put("products", prodList);
				list.add(map);
				//return list;	
			}
			return list;
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
				try {
					if(conn != null){
						conn.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(rs != null){
						rs.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return list;
	}
	
	public List<ProdInfo> selectProdByScb(String scb_code){
		List<ProdInfo> list =new ArrayList<ProdInfo>();
		ResultSet rs1 = null;
		Connection conn1 =null;
		PreparedStatement pstmt1 =null;
		try {
			conn1 =dbutil.getConn();
			String oracle = "SELECT b.prod_id,b.prod_name,b.prod_size,a.dt_scb_price_amt,a.dt_scb_qty,a.dt_scb_total_amt,a.dt_scb_total_pv_amt "
					+ " FROM scb_dt a,prod_detail b WHERE a.dt_scb_prod_code = b.prod_code  AND b.prod_language_type=1 AND a.dt_scb_code = '"+scb_code+"'";
			pstmt1 = conn1.prepareStatement(oracle);
			rs1 = pstmt1.executeQuery();
			//System.out.println("selectProdByScb-----------"+oracle);
			while(rs1.next()){
				ProdInfo prod =new ProdInfo();
				prod.setPid(rs1.getString(1));
				prod.setPname(rs1.getString(2));
				prod.setPsize(rs1.getString(3));
				prod.setPprice(rs1.getBigDecimal(4));
				prod.setPnum(rs1.getInt(5));
				prod.setPtotal(rs1.getBigDecimal(6));
				prod.setPpv(rs1.getBigDecimal(7));
				list.add(prod);
			}
			return list;
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
				try {
					if(conn1 != null){
						conn1.close();
					}
					if(pstmt1 != null){
						pstmt1.close();
					}
					if(rs1 != null){
						rs1.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return list;
	}
	
	
	
	
	public List<MembAnalysis> reportMembAnalysis(String membcode , String month){
		
		List<MembAnalysis> list =new ArrayList<MembAnalysis>();
		try {
			conn =dbutil.getConn();
			String oracle = "SELECT a.dt_bns_bns_code,memb_ms.memb_id,rank_lt.lt_rank_title,a.dt_bns_pv,a.dt_bns_apv,a.dt_bns_amt,1 AS levelnum,memb_ms.memb_name name,a.dt_bns_gpv gpv,a.dt_bns_is_qualified "
					+ " FROM bns_dt a,memb_ms,rank_lt WHERE rank_lt.lt_rank_type = a.dt_bns_rank_type AND rank_lt.lt_rank_language_type =1 AND memb_ms.memb_code = a.dt_bns_memb_code "
					+ " AND a.dt_bns_bns_code = 'BM"+month+"' AND a.dt_bns_memb_code ='"+membcode+"' AND a.dt_bns_amt > 0 "
					+ " UNION "
					+ " SELECT a.dt_bns_bns_code,memb_ms.memb_id,rank_lt.lt_rank_title,a.dt_bns_pv,a.dt_bns_apv,a.dt_bns_amt,2 AS levelnum ,memb_ms.memb_name name,a.dt_bns_gpv gpv,a.dt_bns_is_qualified "
					+ " FROM bns_dt a,memb_ms,rank_lt WHERE rank_lt.lt_rank_type = a.dt_bns_rank_type AND rank_lt.lt_rank_language_type =1 "
					+ " AND memb_ms.memb_code=a.dt_bns_memb_code AND dt_bns_bns_code ='BM"+month+"' AND dt_bns_upline_memb_code ='"+membcode+"' AND dt_bns_amt > 0 "
					+ " UNION "
					+ " SELECT a.dt_bns_bns_code,memb_ms.memb_id,rank_lt.lt_rank_title,a.dt_bns_pv,a.dt_bns_apv,a.dt_bns_amt,3 AS levelnum ,memb_ms.memb_name name,a.dt_bns_gpv gpv,a.dt_bns_is_qualified "
					+ " FROM bns_dt a,memb_ms,rank_lt WHERE rank_lt.lt_rank_type = a.dt_bns_rank_type AND rank_lt.lt_rank_language_type =1 "
					+ " AND memb_ms.memb_code=a.dt_bns_memb_code AND dt_bns_bns_code ='BM"+month+"' AND  dt_bns_upline_memb_code IN(SELECT dt_bns_memb_code FROM bns_dt WHERE dt_bns_upline_memb_code ='"+membcode+"')"
					+ " AND dt_bns_amt > 0 ";
			pstmt = conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			//System.out.println("reportMembAnalysis-------"+oracle);
			while(rs.next()){
				MembAnalysis ma = new MembAnalysis();
				ma.setBns_code(rs.getString(1));
				ma.setDistributorid(rs.getString(2));
				ma.setRank(rs.getString(3));
				ma.setPv(rs.getBigDecimal(4));
				ma.setApv(rs.getBigDecimal(5));
				ma.setBnsTotal(rs.getBigDecimal(6));
				ma.setLevelnum(rs.getInt(7));
				ma.setName(rs.getString(8));
				ma.setGpv(rs.getBigDecimal(9));
				ma.setActive(rs.getString(10));
				list.add(ma);
				//return list;	
			}
			return list;
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
				try {
					if(conn != null){
						conn.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(rs != null){
						rs.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return list;
		
		
		
	}
}
