package com.appinterface.service.impl;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import oracle.jdbc.OracleResultSet;

import com.appinterface.bean.AppOrderInfo;
import com.appinterface.bean.BonusInfo;
import com.appinterface.bean.MemberInfo;
import com.appinterface.bean.UnitInfo;
import com.appinterface.common.DBUtil;

public class GetDateImpl {
	DBUtil dbutil =new DBUtil();
	PreparedStatement pstmt =null;
	ResultSet rs=null;
	Connection conn = null;
	
	/**
	 * 查询登录账号
	 * @param distributorId
	 * @param password
	 * @param imei
	 * @return
	 */
	public String login(String distributorId ,String password,String imei){
		String oracle = "SELECT MEMB_LOGIN_PHONEIMEI FROM MEMB_MS WHERE MEMB_ID ='"+distributorId+"' AND MEMB_PWD='"+password+"'";
		String returnString = "";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs =pstmt.executeQuery();
			System.out.println("lohin-----"+oracle);
			if(rs.next()){ 
				returnString = rs.getString(1);
					
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		
		return returnString;
	}
	
	public String selectMembName(String distributorid){
		String oracle = "SELECT MEMB_NAME FROM MEMB_MS WHERE MEMB_ID ='"+distributorid+"'";
		String name ="";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs =pstmt.executeQuery();
			//System.out.println(oracle);
			if(rs.next()){
				 name =rs.getString(1);
				return name;
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		
		return name;
	}
	
	/**
	 * 登录时 修改imei  表示该账号在该手机上登录
	 * @param distributorId
	 * @param imei
	 */
	public void updateLoginImei(String distributorId,String imei){
		String oracle = "UPDATE MEMB_MS SET MEMB_LOGIN_PHONEIMEI = '"+imei+"' WHERE MEMB_ID='"+distributorId+"'";
		Connection con =null;
		PreparedStatement ps  =null;
		try {
			con = dbutil.getConn();
			ps =con.prepareStatement(oracle);
			ps.executeUpdate();
			System.out.println("login-------"+oracle);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(con != null){
					con.close();
				}
				if(ps != null){
					ps.close();
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		
		
	}
	
	/**
	 * 登录之前查询是否激活
	 * @param distributorid
	 * @return
	 */
	public int activeState(String distributorid){
		String oracle = "SELECT MEMB_ACTIVE_STATE,MEMB_STATUS FROM MEMB_MS WHERE MEMB_ID ='"+distributorid+"'";
		
		System.out.println("activeState--------"+oracle);
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs =pstmt.executeQuery();
			if(rs.next()){
				 if(rs.getString(1).equals("Y")){
				    return 0;
				 }
				return -1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		//System.out.println(oracle);
		return -1;
		
		
	}
	
	/**
	 * 获取该账号的奖金信息
	 * @param distributorId
	 * @param momth
	 * @return
	 */
public List<BonusInfo> getBonusInfo(String distributorId,String momth,String imei){
		
		//BonusInfo bns =new BonusInfo();
		List<BonusInfo> list =new ArrayList<BonusInfo>();
		try {
			conn =dbutil.getConn();
			String oracle = "SELECT dt_bns_bns_code,dt_bns_memb_code,dt_bns_rank_type,"
					+ "dt_bns_sale_amt,dt_bns_pv,dt_bns_apv,dt_bns_opb_amt,dt_bns_ldb_amt,"
					+ "dt_bns_lsb_amt,dt_bns_pgb_point,dt_bns_pgb_amt,dt_bns_lgb_amt,"
					+ "dt_bns_ltf_point,dt_bns_ltf_amt,dt_bns_lcf_point,dt_bns_lcf_amt,dt_bns_lvf_point,"
					+ "dt_bns_lvf_amt,dt_bns_reserve_amt,dt_bns_amt "
					+ "FROM BNS_DT WHERE DT_BNS_BNS_CODE in (SELECT DISTINCT CONCAT('BM',TO_CHAR(TO_DATE('"+momth+"', 'YYYYMM')+1- ROWNUM,'YYYYMM')) FROM BNS_DT WHERE ROWNUM<=365 ) AND DT_BNS_MEMB_CODE =(SELECT MEMB_CODE FROM MEMB_MS WHERE MEMB_ID='"+distributorId+"')";
			pstmt = conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			System.out.println("bonus-------"+oracle);
			while(rs.next()){
				BonusInfo bns =new BonusInfo();
				bns.setDt_bns_bns_code(rs.getString("dt_bns_bns_code"));
				bns.setDt_bns_memb_code(rs.getString("dt_bns_memb_code"));
				bns.setDt_bns_rank_type(rs.getInt("dt_bns_rank_type"));
				bns.setDt_bns_sale_amt(rs.getBigDecimal("dt_bns_sale_amt"));
				bns.setDt_bns_pv(rs.getBigDecimal("dt_bns_pv"));
				bns.setDt_bns_apv(rs.getBigDecimal("dt_bns_apv"));
				bns.setDt_bns_opb_amt(rs.getBigDecimal("dt_bns_opb_amt"));
				bns.setDt_bns_ldb_amt(rs.getBigDecimal("dt_bns_ldb_amt"));
				bns.setDt_bns_lsb_amt(rs.getBigDecimal("dt_bns_lsb_amt"));
				bns.setDt_bns_pgb_point(rs.getBigDecimal("dt_bns_pgb_point"));
				bns.setDt_bns_pgb_amt(rs.getBigDecimal("dt_bns_pgb_amt"));
				bns.setDt_bns_ltf_point(rs.getBigDecimal("dt_bns_ltf_point"));
				bns.setDt_bns_ltf_amt(rs.getBigDecimal("dt_bns_ltf_amt"));
				bns.setDt_bns_lcf_point(rs.getBigDecimal("dt_bns_lcf_point"));
				bns.setDt_bns_lcf_amt(rs.getBigDecimal("dt_bns_lcf_amt"));
				bns.setDt_bns_lvf_point(rs.getBigDecimal("dt_bns_lvf_point"));
				bns.setDt_bns_lvf_amt(rs.getBigDecimal("dt_bns_lvf_amt"));
				bns.setDt_bns_reserve_amt(rs.getBigDecimal("dt_bns_reserve_amt"));
				bns.setDt_bns_amt(rs.getBigDecimal("dt_bns_amt"));
				bns.setDt_bns_lgb_amt(rs.getBigDecimal("dt_bns_lgb_amt"));
				list.add(bns);
				//return list;
				
			}
			return list;
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
				try {
					if(conn != null){
						conn.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(rs != null){
						rs.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return list;
	}

	public int logout(String distributorid,String imei){
		String oracle = "UPDATE MEMB_MS SET MEMB_LOGIN_PHONEIMEI = 'N' WHERE MEMB_ID='"+distributorid+"'";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			pstmt.executeUpdate();
			System.out.println("logout----"+oracle);
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		System.out.println(oracle);
		return -1;
	}
	/**
	 * 查询是否在手机上登录
	 * @param distributorid
	 * @param imei
	 * @return
	 */
	public int imeiAxit(String distributorid,String imei){
		String oracle = "SELECT MEMB_LOGIN_PHONEIMEI FROM MEMB_MS WHERE MEMB_ID ='"+distributorid+"'";
		
		System.out.println(oracle);
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs =pstmt.executeQuery();
			if(rs.next()){
				 if(!rs.getString(1).equals(imei)){
					 return -1;
				 }
				
				return 0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		//System.out.println(oracle);
		return -1;
	} 
	
	/**
	 *   注册 修改激活状态
	 * @param distributorid
	 * @param password
	 * @param invitecode
	 * @return
	 */
	public int register(String distributorid,String password,String invitecode){
		String oracle ="UPDATE MEMB_MS SET MEMB_PWD ='"+password+"', MEMB_ACTIVE_STATE = 'Y' WHERE MEMB_ID = '"+distributorid+"'" ;
		System.out.println("register --------"+oracle);
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			pstmt.executeUpdate();
			return 0;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return -1;
	}
	
	/**
	 *   判断 邀请码  是否正确
	 * @param distributorid
	 * @param invitecode
	 * @return
	 */
	
	public int inviteCode(String distributorid,String invitecode){
		String oracle = "SELECT MEMB_INVITE_CODE FROM MEMB_MS WHERE MEMB_ID ='"+distributorid+"'";
		
		System.out.println("invitecode ----"+oracle);
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs =pstmt.executeQuery();
			if(rs.next()){
				 if(rs.getString(1) == null){
					 return -1;
				 }else if(!rs.getString(1).equals(invitecode)){
					 return -1;
				 }
				
				return 0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		
		return -1;
	} 
	
	/**
	 * 修改密码
	 * @param distributorid
	 * @param password
	 * @return
	 */
	public int updatePwd(String distributorid, String password){
		String oracle = "UPDATE MEMB_MS SET MEMB_PWD = '"+password+"' WHERE MEMB_ID='"+distributorid+"'";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			pstmt.executeUpdate();
			System.out.println("updatePwd----"+oracle);
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return -1;
	}
	
	
	
	public List<MemberInfo> getMemberInfo(String distributorid){
		List<MemberInfo> list =new ArrayList<MemberInfo>();
		try {
			conn =dbutil.getConn();
			String oracle = "SELECT A.MEMB_ID MID,A.MEMB_NAME MNAME,U1.LD_UNIT_NAME COMMNAME,A.MEMB_GENDER_TYPE GENDER,A.MEMB_BIRTH BIRTH, "
					+ " A.MEMB_DOC_NO CARDNO,A.MEMB_PHONE_MOBILE MOBILE,A.MEMB_EMAIL EMAIL,B.MEMB_NAME SPONSOR,C.MEMB_NAME UPLINE,A.MEMB_JOIN_DATE JOINDATE,A.MEMB_KIV KIV,U2.UNIT_ID SHOPID,A.MEMB_PHOTO_STATUS "
					+ " FROM MEMB_MS A, MEMB_MS B,MEMB_MS C,VW_UNIT_DETAIL U1,VW_UNIT_DETAIL U2 "
					+ " WHERE U1.UNIT_CODE = A.MEMB_COMP_UNIT_CODE AND A.MEMB_SPONSOR_MEMB_CODE = B.MEMB_CODE AND A.MEMB_SHOP_CODE = U2.UNIT_CODE "
					+ " AND A.MEMB_UPLINE_MEMB_CODE = C.MEMB_CODE AND U1.LD_UNIT_LANGUAGE_TYPE =1  AND U2.LD_UNIT_LANGUAGE_TYPE =1 AND A.MEMB_ID ='"+distributorid+"'";
			pstmt = conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				MemberInfo memb =new MemberInfo();
				memb.setMemb_id(rs.getString(1));
				memb.setMemb_name(rs.getString(2));
				memb.setCompany_name(rs.getString(3));
				memb.setGender(rs.getInt(4));
				if(rs.getDate(5) == null){
					memb.setMemb_birth("");
				}else{
					memb.setMemb_birth(rs.getDate(5).toString());
				}
				memb.setMemb_doc_no(rs.getString(6));
				memb.setMemb_phone_mobile(rs.getString(7));
				memb.setMemb_email(rs.getString(8));
				memb.setMemb_sponsor_name(rs.getString(9));
				memb.setMemb_upline_name(rs.getString(10));
				memb.setMemb_joindate(rs.getDate(11).toString());
				memb.setKIV(rs.getString(12));
				memb.setShop_id(rs.getString(13));
				memb.setMemb_photo_status(rs.getString(14));
				list.add(memb);
				//return list;
				
			}
			return list;
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
				try {
					if(conn != null){
						conn.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(rs != null){
						rs.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return list;
	}
	
	
	public List<UnitInfo> getMyShop(String distributorid){
		List<UnitInfo> list =new ArrayList<UnitInfo>();
		try {
			conn =dbutil.getConn();
			String oracle = "SELECT A.UNIT_ID,A.LD_UNIT_NAME FROM MEMB_MS B,VW_UNIT_DETAIL A  WHERE B.MEMB_SHOP_CODE = A.UNIT_CODE AND B.MEMB_ID='"+distributorid+"'";
			pstmt = conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				UnitInfo unit =new UnitInfo();
				unit.setUid(rs.getString(1));
				unit.setUname(rs.getString(2));
				list.add(unit);
				//return list;
				
			}
			return list;
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
				try {
					if(conn != null){
						conn.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(rs != null){
						rs.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return list;
		
	}
	
	public int updateMembName(String distributorid,String newname){
		String oracle = "UPDATE MEMB_MS SET MEMB_NAME = '"+newname+"' WHERE MEMB_ID='"+distributorid+"'";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			pstmt.executeUpdate();
			System.out.println("updateMembName----"+oracle);
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return -1;
	}
	//获取 APP订单的id
	public String getOrderid(String t){
		String orderid = "";
		String oracle = "SELECT ( (TO_CHAR(to_number('"+t+"') / (1000 * 60 * 60 * 24) + TO_DATE('1970-01-01 08:00:00', 'YYYY-MM-DD HH:MI:SS'), 'YYYYMM')) || LPAD(SEQ_APPORDER_ID.nextval,8,'0')) a FROM dual";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			//System.out.println("updateMembName----"+oracle);
			if(rs.next()){
				orderid = rs.getString(1);
				return orderid;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return orderid;
	}

	public int insertDetail(JSONArray parray,String orderid) {
		
		try {
			
			for(int i = 0; i<parray.length();i++){
				JSONObject j = (JSONObject) parray.get(i);
				String pid =j.getString("pid");
				String pname = j.getString("pname");
				double price  = j.getDouble("pprice");
				int pnum = j.getInt("pnum");
				String oracle = "INSERT INTO APP_PROD_DETAIL(APD_ID,ORDER_ID,PID,PNAME,PRICE,PNUM,PTOTAL) VALUES (SEQ_APPDETAIL_ID.NEXTVAL,'"+orderid+"','"+pid+"','"+pname+"',"+price+","+pnum+","+price*pnum+") ";
				conn = dbutil.getConn();
				pstmt =conn.prepareStatement(oracle);
				pstmt.executeUpdate();
			}
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return -1;
	}

	public double getTotal(String orderid) {
		double total = 0.00;
		String oracle = "SELECT SUM(ptotal) FROM APP_PROD_DETAIL WHERE order_id = '"+orderid+"'";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			System.out.println("getTotal----"+oracle);
			if(rs.next()){
				total = rs.getDouble(1);
				return total;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return total;
	}

	public int insertOrder(String orderid,String distributorid, String t, double total) {
		String oracle = "INSERT INTO APP_ORDER(ORDER_ID,ORDER_DATETIME,MEMB_ID,ORDER_TOTAL,ORDER_STATUS) "
				+ " VALUES('"+orderid+"',to_number('"+t+"') / (1000 * 60 * 60 * 24) +  TO_DATE('1970-01-01 08:00:00', 'YYYY-MM-DD HH:MI:SS'),'"+distributorid+"',"+total+",1)";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			pstmt.executeUpdate();
			//System.out.println("updateMembName----"+oracle);
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return -1;
	}

	public List<HashMap<String,Object>> getMyOrder(String distributorid){
		List<HashMap<String,Object>> list = new ArrayList<HashMap<String,Object>>();
		try {
			conn =dbutil.getConn();
			String oracle = "select order_id,order_datetime,memb_id, ORDER_TOTAL from APP_ORDER where memb_id = '"+distributorid+"' and rownum <50 order by order_datetime desc ";
			pstmt = conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				HashMap<String,Object> map = new HashMap<String, Object>();
				String orderid = new String();
				String ordertime = new String();
				String membid = new String();
				Double total ;
				
				orderid =rs.getString(1);
				ordertime = rs.getString(2);
				membid = rs.getString(3);
				total = rs.getDouble(4); 
				List<AppOrderInfo> prodList= new ArrayList<AppOrderInfo>();
				prodList = findProdByOrderid(orderid);
				map.put("orderid", orderid);
				map.put("ordertime", ordertime);
				map.put("membid", membid);
				map.put("products", prodList);
				map.put("total", total);
				list.add(map);
			}
			return list;
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
				try {
					if(conn != null){
						conn.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(rs != null){
						rs.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return list;
		
	}

	public List<AppOrderInfo> findProdByOrderid(String orderid){
		List<AppOrderInfo> list =new ArrayList<AppOrderInfo>();
		ResultSet rs1 = null;
		try {
			conn =dbutil.getConn();
			String oracle = "select pid,pname,pnum,price from app_prod_detail where order_id = '"+orderid+"'";
			pstmt = conn.prepareStatement(oracle);
			rs1 = pstmt.executeQuery();
			System.out.println("findProdByOrderid-----------"+oracle);
			while(rs1.next()){
				AppOrderInfo prod =new AppOrderInfo();
				prod.setPid(rs1.getString(1));
				prod.setPname(rs1.getString(2));
				prod.setPnum(rs1.getInt(3));
				prod.setPrice(rs1.getDouble(4));
				list.add(prod);
			}
			return list;
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
				try {
					if(conn != null){
						conn.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(rs1 != null){
						rs1.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	
		return list;
	}
	
	
	
	public String getBnscode(String memb_code){
		String bns_code = "";
		String oracle = "SELECT dt_bns_bns_code FROM bns_dt WHERE dt_bns_memb_code ='"+memb_code+"' AND  ROWNUM =1 ORDER BY dt_bns_bns_code DESC";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			//System.out.println("updateMembName----"+oracle);
			if(rs.next()){
				bns_code = rs.getString(1);
				return bns_code;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return bns_code;
	}
	
	
	public HashMap<String,Object> getTopup(String memb_code,String bns_code){
		HashMap<String,Object> map = new HashMap<String,Object>();
		String oracle = "SELECT dt_bns_rank_type, dt_bns_pv pv,dt_bns_apv cpv "
				+ " FROM bns_dt WHERE dt_bns_rank_type >=1 AND dt_bns_memb_code ='"+memb_code+"'  AND dt_bns_bns_code = '"+bns_code+"' ";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			System.out.println("getTopup----"+oracle);
			if(rs.next()){
				
				
				map.put("rank", rs.getInt(1));
				map.put("pv", rs.getBigDecimal(2));
				map.put("cpv", rs.getBigDecimal(3));
				return map;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return map;
	}
	
	
	/**
	 * 上传照片
	 * @param path
	 * @param distributorid
	 * @return
	 */
	public int uploadPhoto(String photo,String distributorid){
		
		
		try {
			conn = dbutil.getConn();
			 conn.setAutoCommit(false); 
			 
			 PreparedStatement pst =  conn.prepareStatement("update memb_ms set memb_photo_status = '"+System.currentTimeMillis()+"' where memb_id = ?"); 
			 pst.setString(1,distributorid); 
			 pst.executeUpdate(); 
			 pst.close(); 
			 
		     ByteArrayInputStream fis = new ByteArrayInputStream(photo.getBytes());
		 
		     oracle.sql.BLOB blob = null;    //注意此处的Blob格式一定要是oracle.sql.BLOB
		    //插入Blob的时候是先插一个空的Blob然后用UPDATE修改它
		      PreparedStatement pstmt = conn.prepareStatement("update memb_ms set memb_photo = empty_blob() where memb_id = ?"); 
		      pstmt.setString(1,distributorid); 
		      pstmt.executeUpdate(); 
		      pstmt.close(); 
		      pstmt = conn.prepareStatement("select memb_photo from memb_ms where memb_id= ? for update"); 
		      pstmt.setString(1,distributorid); 
		      ResultSet rs = pstmt.executeQuery(); 
		     if (rs.next()) blob = (oracle.sql.BLOB)((OracleResultSet)rs).getBlob(1); 
		 
		      pstmt = conn.prepareStatement("update memb_ms set memb_photo=? where memb_id=?"); 
		      OutputStream out1 = blob.getBinaryOutputStream();  // 建立输出流

		      byte[] data = new byte[(int)fis.available()]; 
		      fis.read(data); 
		      out1.write(data); 
		      out1.close(); 
		      fis.close(); 
		 
		      pstmt.setBlob(1,blob); 
		      pstmt.setString(2,distributorid); 
		 
		      pstmt.executeUpdate(); 
		      conn.commit();
		      pstmt.close(); 
			
			
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{ 
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		//conn.setAutoCommit(defaultCommit);
		return -1;
	}
	
	/**
	 *  显示照片
	 * @param distributorid
	 * @return  照片的byte数组   
	 */
	
	public String getphoto(String distributorid){
		java.sql.Blob blob =null;
		String photo ="";
		try {
			String oracle = "select memb_photo from memb_ms where memb_id = '"+distributorid+"'";
			System.out.println(oracle);
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			StringBuffer sb = new StringBuffer();
			if(rs.next()){
				blob = (oracle.sql.BLOB)((OracleResultSet)rs).getBlob(1);
				InputStream is = blob.getBinaryStream();
				BufferedInputStream input = new BufferedInputStream(is);
				if(input != null){
					   //在这里执行写入，如写入到文件的BufferedOutputStream里
						BufferedReader tBufferedReader = new BufferedReader(new InputStreamReader(input));
						StringBuffer tStringBuffer = new StringBuffer();
						String sTempOneLine = new String("");
						while ((sTempOneLine = tBufferedReader.readLine()) != null){
							tStringBuffer.append(sTempOneLine);
							}
						photo =tStringBuffer.toString();
					   System.out.println(tStringBuffer.toString());
					   tBufferedReader.close();
					   is.close();
					   input.close();
					   return photo;
					  }
				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return photo;
	}
	
	/**
	 * 点赞  存到数据库
	 * @param distributorid
	 * @param pid
	 * @return
	 */
	public int insertOptIn(String distributorid,String pid){

		String oracle = "insert into app_opt_in(memb_id,prod_id) values('"+distributorid+"','"+pid+"')";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			pstmt.executeUpdate();
			//System.out.println("updateMembName----"+oracle);
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return -1;
	}
	
	/**
	 * 点赞数
	 * @param pid
	 * @return 点赞数
	 */
	public int selectOptIn(String pid){

		int count = 0;
		String oracle = "select count(*) from app_opt_in where prod_id ='"+pid+"'";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			System.out.println("selectOptIn----"+oracle);
			if(rs.next()){
				count = rs.getInt(1);
				return count;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return count;
	}

	public List<MemberInfo> getStarMemb(String bnscode) {
		List<MemberInfo> list =new ArrayList<MemberInfo>();
		try {
			conn =dbutil.getConn();
			String oracle ="SELECT A.MEMB_ID           MID,"
       +	" A.MEMB_NAME         MNAME,"
       +	" D.LD_UNIT_NAME     COMMNAME,"
       +	" A.MEMB_GENDER_TYPE  GENDER,"
       +	" A.MEMB_BIRTH        BIRTH,"
       +	" A.MEMB_DOC_NO       CARDNO,"
       +	" A.MEMB_PHONE_MOBILE MOBILE,"
       +	" A.MEMB_EMAIL        EMAIL,"
       +	" E.MEMB_NAME         SPONSOR,"
       +	" F.MEMB_NAME         UPLINE,"
       +	" A.MEMB_JOIN_DATE    JOINDATE,"
       +	" A.MEMB_KIV          KIV,"
       +	" B.UNIT_ID          SHOPID,"
       +	" A.MEMB_PHOTO_STATUS"
       +	" FROM MEMB_MS A,MEMB_MS E,MEMB_MS F,VW_UNIT_DETAIL B,VW_UNIT_DETAIL D,"
       +	" (SELECT DT_BNS_MEMB_CODE, DT_BNS_SALE_AMT"
       +	" FROM (SELECT DT_BNS_MEMB_CODE, DT_BNS_SALE_AMT FROM BNS_DT WHERE DT_BNS_BNS_CODE = '"+bnscode+"' ORDER BY DT_BNS_SALE_AMT DESC)"
       +	" WHERE ROWNUM <= 20) C"
       +	" WHERE C.DT_BNS_MEMB_CODE = A.MEMB_CODE(+) "
       +	" AND A.MEMB_SPONSOR_MEMB_CODE=E.MEMB_CODE(+)"
      +	" AND A.MEMB_UPLINE_MEMB_CODE=F.MEMB_CODE(+)"
      +	" AND A.MEMB_SHOP_CODE=B.UNIT_CODE(+) AND NVL(B.LD_UNIT_LANGUAGE_TYPE,1)=1"
      +	" AND A.MEMB_COMP_UNIT_CODE=D.UNIT_CODE(+) AND NVL(D.LD_UNIT_LANGUAGE_TYPE,1)=1"
      +	" ORDER BY C.DT_BNS_SALE_AMT DESC";
			pstmt = conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				MemberInfo memb =new MemberInfo();
				memb.setMemb_id(rs.getString(1));
				memb.setMemb_name(rs.getString(2));
				memb.setCompany_name(rs.getString(3));
				memb.setGender(rs.getInt(4));
				if(rs.getDate(5) == null){
					memb.setMemb_birth("");
				}else{
					memb.setMemb_birth(rs.getDate(5).toString());
				}
				memb.setMemb_doc_no(rs.getString(6));
				memb.setMemb_phone_mobile(rs.getString(7));
				memb.setMemb_email(rs.getString(8));
				memb.setMemb_sponsor_name(rs.getString(9));
				memb.setMemb_upline_name(rs.getString(10));
				memb.setMemb_joindate(rs.getDate(11).toString());
				memb.setKIV(rs.getString(12));
				memb.setShop_id(rs.getString(13));
				memb.setMemb_photo_status(rs.getString(14));
				list.add(memb);
				//return list;
				
			}
			return list;
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
				try {
					if(conn != null){
						conn.close();
					}
					if(pstmt != null){
						pstmt.close();
					}
					if(rs != null){
						rs.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return list;
	}

	public String  getMonth() {
		// TODO Auto-generated method stub
		String bns_code = "";
		String oracle = "SELECT 'BM'|| TO_CHAR(EXTRACT(YEAR FROM SYSDATE-30)) || TO_CHAR(LPAD(EXTRACT(MONTH FROM SYSDATE-30),2,'0')) FROM DUAL";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			//System.out.println("updateMembName----"+oracle);
			if(rs.next()){
				bns_code = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return bns_code;
	}

	public Map<String, Object> getLoginReturn(String distributorid) {
		Map<String,Object> map = new HashMap<String,Object>();
		String oracle = "SELECT   m.memb_name,m.memb_photo_status,u.unit_id "+
				" FROM memb_ms m "+
				" LEFT JOIN unit_ms u ON m.memb_shop_code = u.unit_code "
				+ "WHERE  m.memb_id ='"+distributorid+"'";
		try {
			conn = dbutil.getConn();
			pstmt =conn.prepareStatement(oracle);
			rs = pstmt.executeQuery();
			System.out.println("getTopup----"+oracle);
			if(rs.next()){
				String memb_photo_status = rs.getString(2);
				String shop_id = rs.getString(3);
				if(memb_photo_status == null){
					memb_photo_status ="";
				}
				if(shop_id == null){
					shop_id = "";
				}
				map.put("memb_name", rs.getString(1));
				map.put("memb_photo_status", memb_photo_status);
				map.put("shop_id", shop_id);
				return map;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				if(conn != null){
					conn.close();
				}
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return map;
	}

	
	
}
