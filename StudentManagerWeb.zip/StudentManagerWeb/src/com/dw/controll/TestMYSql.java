package com.dw.controll;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestMYSql {
	public static void main(String[] args) {  
        Connection conn = null;  
        try {  
            Class.forName("com.mysql.jdbc.Driver");  
        } catch (ClassNotFoundException e) {  
            System.out.println("无法加载驱动");  
        }  
        try {  
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "");  
        } catch (SQLException e) {  
            System.out.println("无法连接数据库");  
        }  
        try {  
            Statement stmt = conn.createStatement();  
            ResultSet rs = stmt.executeQuery("SELECT * FROM student2");  
            while(rs.next()) {  
            	String name = rs.getString(2);
                System.out.println(name+"");  
            }  
        } catch (SQLException e) {  
            System.out.println("无法查询");  
        }  
          
    }  
}
